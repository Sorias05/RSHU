a=input("Input 1 number: ")
b=input("Input 2 number: ")
c=input("Input 3 number: ")
print(f'{c} {b} {a}')